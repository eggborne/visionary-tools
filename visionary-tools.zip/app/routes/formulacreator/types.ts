export interface IngredientData {
  name: string;
  pendingAmount: number;
  totalAmount: number;
}